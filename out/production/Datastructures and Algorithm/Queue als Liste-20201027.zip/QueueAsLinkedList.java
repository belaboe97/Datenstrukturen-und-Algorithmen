package queue;

public class QueueAsLinkedList {

    private Elem begin = null;
    private Elem end = null;
    private int number = 0;

    boolean isEmpty() {
        return number == 0;
    }

    void put(int value) {
        Elem new_elem = new Elem(value);
        if (isEmpty()) {
            begin = new_elem;
        }
        else {
            end.next = new_elem;
        }
        end = new_elem;
        number++;
    }

    int get() throws QueueError {
        if (isEmpty()) {
            throw new QueueError("Queue leer.");
        }

        Elem cursor = begin;
        begin = begin.next;
        if (begin == null) {
            end = null;
        }

        number--;
        return cursor.number;
    }

}
