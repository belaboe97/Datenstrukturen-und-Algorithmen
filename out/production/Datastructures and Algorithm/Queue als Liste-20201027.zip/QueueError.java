package queue;

public class QueueError extends Exception{

    public QueueError() {
        super();
    }

    public QueueError(String message) {
        super(message);
    }
}
