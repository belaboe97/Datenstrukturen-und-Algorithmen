package queue;

public class Elem {
    int number;
    Elem next = null;

    Elem (int n) {
        number = n;
    }
}
