package queue;

public class QueueMain {
    public static void main(String[] args) {
        QueueAsLinkedList queue = new QueueAsLinkedList();

        queue.put(2);
        queue.put(3);
        queue.put(5);

        try {
            System.out.println(queue.get());
            System.out.println(queue.get());
            System.out.println(queue.get());
            System.out.println(queue.get());
        } catch (QueueError queueError) {
            System.out.println(queueError.getMessage());
        }
    }
}
